# CyberShield: A Beginner's Cybersecurity Toolkit

Capstone project in Python. It runs on your own computer and opens in the web browser.

## Problem Statement
Weak passwords, phishing links, unnoticed file changes, repeated login attacks and
unnecessary open ports are common security risks. Beginners need one simple tool
to understand and detect them.

## Objectives
1. Measure password strength and generate strong passwords.
2. Warn about suspicious (possible phishing) URLs.
3. Detect modified, added and deleted files.
4. Detect brute-force login attempts from log data.
5. Show open ports on the local computer.

## Requirements
- Python 3.8 or newer
- A web browser
- No extra libraries

## How to Run
1. Install Python from https://www.python.org/downloads/ (on Windows, tick "Add python.exe to PATH").
2. Unzip the project and open a terminal inside the `cybershield` folder
   (the folder that contains `main.py`).
3. Run:

       python main.py

   On Mac or Linux use `python3 main.py`.
4. The app opens at http://127.0.0.1:5000. Press Ctrl+C in the terminal to stop.

If port 5000 is busy (common on Mac), run `python main.py 5050`.

## How to Test

    python -m unittest discover -s tests -v

## Demo Steps
| Tab | What to do | Expected result |
|-----|------------|-----------------|
| Password | Check `password123` | Weak |
| Phishing URL | Check `http://secure-login-verify.example.xyz/account` | High risk |
| File Integrity | Use sample folder, Create baseline, edit `notes.txt`, Check for changes | Modified: notes.txt |
| Log Analyzer | Load sample log, Analyze | 2 suspicious IPs (one CRITICAL) |
| Port Scanner | Scan 1 to 6000 | Lists open ports, including this app's own port 5000 |

## Project Structure

    cybershield/
      main.py                 starts the local web server
      web/index.html          user interface
      security/
        password_checker.py   entropy and rule checks
        url_checker.py        phishing warning signs
        file_integrity.py     SHA-256 file monitoring
        log_analyzer.py       brute-force detection
        port_scanner.py       localhost port scan
      sample_data/            demo log and folder
      tests/                  automated tests

## How It Works
    Browser (HTML + JavaScript)  ->  main.py (Python server)  ->  security modules

| Module | Concept used |
|--------|--------------|
| Password | Entropy = length x log2(character pool), plus a common-password list |
| URL | Rule-based scoring of warning signs |
| File Integrity | SHA-256 hashing and comparison with a saved baseline |
| Log Analyzer | Regular expressions and counting failures per IP address |
| Port Scanner | TCP connection attempts using sockets and threads |

## Security Measures in the App
- The server listens only on 127.0.0.1.
- Host and Content-Type headers are checked.
- Output is shown with `textContent`, which prevents script injection.
- Passwords are never saved or logged.
- The port scanner cannot scan other computers.

## Limitations
- URL checking is rule-based, so it can miss scams or flag genuine sites.
- Password score is an estimate; it does not check leaked-password databases.
- Log analyzer reads SSH password log lines and does not consider time gaps.
- File monitoring runs only when you click the button.

## Future Scope
- Machine learning model for phishing detection
- Real-time file monitoring with email alerts
- PDF report export
- More log formats

## Ethical Use
For learning and defensive use only.
