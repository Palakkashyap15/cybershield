"""CyberShield: start this file, then use the app in your web browser.

    python main.py

Only Python's standard library is used, so nothing has to be installed.
"""
import json
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from security import (file_integrity, log_analyzer, password_checker,
                      port_scanner, url_checker)

BASE_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"   # only this computer can reach the app
PORT = 5000
MAX_BODY = 2_000_000  # largest request accepted, in bytes


def sample_data():
    folder = BASE_DIR / "sample_data"
    return {"log": (folder / "auth.log").read_text(encoding="utf-8"),
            "folder": str(folder / "protected_folder")}


# Each address the web page can call, and the function that answers it.
ROUTES = {
    "/api/password": lambda d: password_checker.check_password(d["password"]),
    "/api/generate": lambda d: {
        "password": password_checker.generate_password(d.get("length", 16))},
    "/api/url": lambda d: url_checker.check_url(d["url"]),
    "/api/baseline": lambda d: file_integrity.create_baseline(d["folder"]),
    "/api/integrity": lambda d: file_integrity.check_integrity(d["folder"]),
    "/api/logs": lambda d: log_analyzer.analyze_log(
        d["log"], d.get("threshold", 5)),
    "/api/ports": lambda d: port_scanner.scan_ports(d["start"], d["end"]),
    "/api/sample": lambda d: sample_data(),
}


class Handler(BaseHTTPRequestHandler):
    def send(self, status, body, content_type="application/json"):
        if not isinstance(body, bytes):
            body = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def host_is_local(self):
        """Reject requests addressed to any other name (DNS rebinding)."""
        port = self.server.server_address[1]
        return self.headers.get("Host") in (f"127.0.0.1:{port}",
                                            f"localhost:{port}")

    def do_GET(self):
        if not self.host_is_local():
            self.send(403, {"error": "Forbidden"})
        elif self.path == "/":
            page = (BASE_DIR / "web" / "index.html").read_bytes()
            self.send(200, page, "text/html")
        else:
            self.send(404, {"error": "Page not found"})

    def do_POST(self):
        # Requiring JSON stops other websites from silently using this app.
        if (not self.host_is_local()
                or self.headers.get("Content-Type") != "application/json"):
            return self.send(403, {"error": "Forbidden"})
        action = ROUTES.get(self.path)
        if action is None:
            return self.send(404, {"error": "Unknown action"})
        try:
            length = int(self.headers.get("Content-Length", 0))
            if not 0 <= length <= MAX_BODY:
                return self.send(413, {"error": "Input is too large."})
            data = json.loads(self.rfile.read(length) or b"{}")
            self.send(200, action(data))
        except (ValueError, KeyError, TypeError, AttributeError, OSError) as error:
            self.send(400, {"error": str(error)})

    def log_message(self, *args):
        pass  # keep the terminal clean and never print passwords


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    try:
        server = ThreadingHTTPServer((HOST, port), Handler)
    except OSError:
        print(f"Port {port} is busy. Try:  python main.py 5050")
        return
    address = f"http://{HOST}:{port}"
    print(f"CyberShield is running at {address}")
    print("Press Ctrl+C to stop.")
    threading.Timer(1, webbrowser.open, [address]).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
