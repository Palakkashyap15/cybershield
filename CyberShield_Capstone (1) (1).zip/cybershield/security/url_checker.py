"""Module 2: look for common warning signs of a phishing link.

The URL is only read as text. The program never opens or visits it.
"""
import ipaddress
from urllib.parse import urlsplit

SUSPICIOUS_WORDS = ["login", "verify", "update", "secure", "account",
                    "banking", "confirm", "password", "free", "winner", "kyc"]
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly"}
RISKY_ENDINGS = (".xyz", ".top", ".tk", ".ml", ".gq", ".cf", ".zip", ".click")


def _is_ip_address(host):
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def check_url(url):
    """Return a risk score (0-100), a verdict and the reasons."""
    url = url.strip()
    if not url:
        return {"score": 0, "verdict": "Empty", "reasons": ["Type a URL."]}
    if "://" not in url:
        url = "http://" + url

    try:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()
        _ = parts.port  # raises ValueError if the port is not valid
    except ValueError:
        host = ""
    if not host:
        return {"score": 0, "verdict": "Invalid",
                "reasons": ["This does not look like a web address."]}

    score = 0
    reasons = []

    def flag(points, reason):
        nonlocal score
        score += points
        reasons.append(reason)

    if parts.scheme != "https":
        flag(20, "Does not use HTTPS.")
    if "@" in parts.netloc:
        flag(30, "Contains '@', which can hide the real website.")
    if _is_ip_address(host):
        flag(35, "Uses an IP address instead of a domain name.")
    else:
        if host.count(".") >= 4:
            flag(15, "Has many subdomains.")
        if host.count("-") >= 2:
            flag(15, "Has several hyphens in the domain.")
        if "xn--" in host or not host.isascii():
            flag(30, "Uses special characters that can imitate other letters.")
        if host.endswith(RISKY_ENDINGS):
            flag(20, "Uses a domain ending often seen in scams.")
    if host in SHORTENERS:
        flag(25, "Shortened link, so the destination is hidden.")
    if len(url) > 75:
        flag(10, "The URL is unusually long.")
    found = [word for word in SUSPICIOUS_WORDS if word in url.lower()]
    if found:
        flag(min(30, 10 * len(found)),
             "Contains suspicious words: " + ", ".join(found) + ".")

    score = min(score, 100)
    if score >= 60:
        verdict = "High risk"
    elif score >= 30:
        verdict = "Suspicious"
    else:
        verdict = "Low risk"

    return {"score": score, "verdict": verdict, "host": host,
            "reasons": reasons or ["No warning signs found. This does not "
                                   "prove the site is safe."]}
