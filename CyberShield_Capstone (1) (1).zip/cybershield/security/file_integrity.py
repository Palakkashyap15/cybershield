"""Module 3: detect changed, new or deleted files using SHA-256 hashes."""
import hashlib
import json
from pathlib import Path

DEFAULT_DATABASE = Path(__file__).resolve().parent.parent / "data" / "baseline.json"
MAX_FILES = 2000  # stops someone scanning a whole drive by mistake


def hash_file(path):
    """Return the SHA-256 fingerprint of a file, reading it in small pieces."""
    sha = hashlib.sha256()
    with open(path, "rb") as file:
        for chunk in iter(lambda: file.read(65536), b""):
            sha.update(chunk)
    return sha.hexdigest()


def _resolve_folder(folder):
    if not str(folder).strip():
        raise ValueError("Type a folder path.")
    path = Path(str(folder).strip().strip('"')).expanduser().resolve()
    if not path.is_dir():
        raise ValueError(f"Folder not found: {path}")
    return path


def scan_folder(folder, database=DEFAULT_DATABASE):
    """Return {relative file name: hash} for every file in the folder."""
    folder = _resolve_folder(folder)
    database = Path(database).resolve()
    hashes = {}
    for path in sorted(folder.rglob("*")):
        if path.is_symlink() or not path.is_file() or path == database:
            continue
        if len(hashes) >= MAX_FILES:
            raise ValueError(f"Too many files (limit {MAX_FILES}). "
                             "Choose a smaller folder.")
        name = path.relative_to(folder).as_posix()
        try:
            hashes[name] = hash_file(path)
        except OSError:
            hashes[name] = "UNREADABLE"
    return hashes


def _load(database):
    database = Path(database)
    if not database.exists():
        return {}
    return json.loads(database.read_text(encoding="utf-8"))


def create_baseline(folder, database=DEFAULT_DATABASE):
    """Remember the current state of the folder."""
    path = _resolve_folder(folder)
    hashes = scan_folder(path, database)
    data = _load(database)
    data[str(path)] = hashes
    Path(database).parent.mkdir(parents=True, exist_ok=True)
    Path(database).write_text(json.dumps(data, indent=2), encoding="utf-8")
    return {"folder": str(path), "files": len(hashes)}


def check_integrity(folder, database=DEFAULT_DATABASE):
    """Compare the folder with the saved baseline."""
    path = _resolve_folder(folder)
    old = _load(database).get(str(path))
    if old is None:
        raise ValueError("No baseline for this folder. Create a baseline first.")
    new = scan_folder(path, database)
    return {
        "folder": str(path),
        "modified": sorted(n for n in old.keys() & new.keys() if old[n] != new[n]),
        "added": sorted(new.keys() - old.keys()),
        "deleted": sorted(old.keys() - new.keys()),
    }
