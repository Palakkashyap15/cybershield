"""Module 1: check how strong a password is, and generate strong ones."""
import math
import secrets
import string

# A short list of very common passwords. Attackers try these first.
COMMON_PASSWORDS = {
    "123456", "123456789", "12345678", "password", "password1", "password123",
    "qwerty", "qwerty123", "abc123", "111111", "123123", "admin", "admin123",
    "welcome", "iloveyou", "letmein", "monkey", "dragon", "india123",
}

SYMBOLS = "!@#$%^&*()-_=+?"


def check_password(password):
    """Return a dictionary with a score (0-100), a label and suggestions."""
    if not password:
        return {"score": 0, "label": "Empty", "entropy_bits": 0,
                "tips": ["Type a password."]}

    tips = []
    pool = 0  # how many different characters an attacker has to try
    groups = [
        (string.ascii_lowercase, "Add a lowercase letter."),
        (string.ascii_uppercase, "Add an uppercase letter."),
        (string.digits, "Add a number."),
        (string.punctuation, "Add a symbol such as ! @ #."),
    ]
    for characters, tip in groups:
        if any(c in characters for c in password):
            pool += len(characters)
        else:
            tips.append(tip)
    if any(c not in string.ascii_letters + string.digits + string.punctuation
           for c in password):
        pool += 32  # spaces and other characters

    # Entropy = length x log2(pool). More bits means harder to guess.
    entropy = len(password) * math.log2(pool)
    score = min(100, int(entropy * 1.25))

    if len(password) < 12:
        tips.insert(0, "Use at least 12 characters.")
        score = min(score, 60)
    if len(set(password)) <= len(password) // 2:
        tips.append("Avoid repeating the same characters.")
        score = min(score, 50)
    lowered = password.lower()
    if any(run in lowered for run in ("1234", "abcd", "qwer")):
        tips.append("Avoid easy patterns like 1234, abcd or qwer.")
        score = min(score, 50)
    if lowered in COMMON_PASSWORDS:
        tips.insert(0, "This is a very common password. Change it.")
        score = 5

    if score < 40:
        label = "Weak"
    elif score < 70:
        label = "Medium"
    else:
        label = "Strong"

    return {"score": score, "label": label, "entropy_bits": round(entropy, 1),
            "tips": tips or ["No problems found by these checks."]}


def generate_password(length=16):
    """Create a random password using the secure 'secrets' module."""
    length = max(12, min(int(length), 64))
    groups = [string.ascii_lowercase, string.ascii_uppercase,
              string.digits, SYMBOLS]
    # Keep trying until every group appears at least once.
    while True:
        password = "".join(secrets.choice("".join(groups)) for _ in range(length))
        if all(any(c in group for c in password) for group in groups):
            if check_password(password)["label"] == "Strong":
                return password
