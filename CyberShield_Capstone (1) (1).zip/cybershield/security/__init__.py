"""Security modules used by the CyberShield toolkit."""
