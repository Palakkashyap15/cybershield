"""Module 4: find possible brute-force attacks in a login log."""
import re
from collections import Counter

# Matches lines in the style of a Linux SSH log, for example:
#   Failed password for root from 203.0.113.5 port 4022 ssh2
#   Accepted password for palak from 192.168.1.10 port 5000 ssh2
LINE_PATTERN = re.compile(
    r"(?P<result>Failed|Accepted) password for (?:invalid user )?"
    r"(?P<user>\S+) from (?P<ip>[0-9a-fA-F.:]+) port"
)


def analyze_log(text, threshold=5):
    """Count logins per IP address and flag those with many failures.

    An IP is flagged when it has `threshold` or more failed logins.
    It is marked critical if a login succeeds after that many failures.
    """
    threshold = max(1, int(threshold))
    failed = Counter()
    users = {}
    breached = set()
    successful = 0

    for line in text.splitlines():
        match = LINE_PATTERN.search(line)
        if not match:
            continue
        ip = match["ip"]
        if match["result"] == "Failed":
            failed[ip] += 1
            users.setdefault(ip, set()).add(match["user"])
        else:
            successful += 1
            if failed[ip] >= threshold:
                breached.add(ip)

    alerts = []
    for ip, count in failed.most_common():
        if count >= threshold:
            alerts.append({
                "ip": ip,
                "failed_attempts": count,
                "users_tried": sorted(users[ip]),
                "severity": "CRITICAL" if ip in breached else "WARNING",
            })

    return {"total_failed": sum(failed.values()),
            "total_successful": successful, "alerts": alerts}
