"""Module 5: find open ports on YOUR OWN computer.

For safety and legal reasons this scanner only checks 127.0.0.1 (localhost).
Scanning other people's computers without permission can be illegal.
"""
import socket
from concurrent.futures import ThreadPoolExecutor

TARGET = "127.0.0.1"

SERVICES = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP",
    135: "Windows RPC", 139: "NetBIOS", 443: "HTTPS", 445: "SMB",
    3306: "MySQL", 3389: "Remote Desktop", 5432: "PostgreSQL",
    8000: "Web app", 8080: "Web app", 27017: "MongoDB",
}


def is_open(port):
    """Try to connect to one port. Success means something is listening."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.3)
        return sock.connect_ex((TARGET, port)) == 0


def scan_ports(start=1, end=1024):
    start, end = int(start), int(end)
    if not (1 <= start <= end <= 65535):
        raise ValueError("Ports must be between 1 and 65535, start <= end.")
    if end - start >= 10000:
        raise ValueError("Scan at most 10000 ports at a time.")
    ports = range(start, end + 1)
    with ThreadPoolExecutor(max_workers=100) as pool:
        results = list(pool.map(is_open, ports))
    open_ports = [{"port": p, "service": SERVICES.get(p, "Unknown")}
                  for p, found in zip(ports, results) if found]
    return {"target": TARGET, "scanned": len(ports), "open_ports": open_ports}
