"""Run from the project folder with:  python -m unittest discover -s tests -v"""
import json
import socket
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import main
from security import (file_integrity, log_analyzer, password_checker,
                      port_scanner, url_checker)


class PasswordTests(unittest.TestCase):
    def test_common_password_is_weak(self):
        self.assertEqual(password_checker.check_password("password123")["label"], "Weak")

    def test_long_mixed_password_is_strong(self):
        result = password_checker.check_password("T7#kqv9!Lm2$Xp4z")
        self.assertEqual(result["label"], "Strong")

    def test_repeated_characters_are_not_strong(self):
        self.assertNotEqual(password_checker.check_password("aaaaaaaaaaaaaaaaaaaa")["label"], "Strong")

    def test_empty_password(self):
        self.assertEqual(password_checker.check_password("")["score"], 0)

    def test_generated_password(self):
        for _ in range(200):
            password = password_checker.generate_password(16)
            self.assertEqual(len(password), 16)
            self.assertEqual(password_checker.check_password(password)["label"], "Strong")


class UrlTests(unittest.TestCase):
    def test_normal_site(self):
        self.assertEqual(url_checker.check_url("https://www.python.org")["verdict"], "Low risk")

    def test_phishing_style_url(self):
        result = url_checker.check_url("http://secure-login-verify.example.xyz/account")
        self.assertEqual(result["verdict"], "High risk")

    def test_ip_address(self):
        result = url_checker.check_url("http://192.0.2.1/login")
        self.assertEqual(result["verdict"], "High risk")

    def test_invalid_input(self):
        for bad in ("http://", "http://[abc", "http://site.com:abc"):
            self.assertEqual(url_checker.check_url(bad)["verdict"], "Invalid")


class FileIntegrityTests(unittest.TestCase):
    def test_detects_all_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp) / "files"
            folder.mkdir()
            database = Path(temp) / "baseline.json"
            (folder / "a.txt").write_text("one")
            (folder / "b.txt").write_text("two")
            file_integrity.create_baseline(folder, database)
            clean = file_integrity.check_integrity(folder, database)
            self.assertEqual((clean["modified"], clean["added"], clean["deleted"]), ([], [], []))

            (folder / "a.txt").write_text("changed")
            (folder / "b.txt").unlink()
            (folder / "c.txt").write_text("new")
            result = file_integrity.check_integrity(folder, database)
            self.assertEqual(result["modified"], ["a.txt"])
            self.assertEqual(result["added"], ["c.txt"])
            self.assertEqual(result["deleted"], ["b.txt"])

    def test_needs_baseline(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                file_integrity.check_integrity(temp, Path(temp) / "none.json")


class LogTests(unittest.TestCase):
    def test_sample_log(self):
        text = main.sample_data()["log"]
        result = log_analyzer.analyze_log(text)
        alerts = {a["ip"]: a["severity"] for a in result["alerts"]}
        self.assertEqual(alerts, {"203.0.113.5": "WARNING", "198.51.100.23": "CRITICAL"})
        self.assertEqual(result["total_failed"], 12)
        self.assertEqual(result["total_successful"], 3)


class PortTests(unittest.TestCase):
    def test_finds_open_port(self):
        with socket.socket() as server:
            server.bind(("127.0.0.1", 0))
            server.listen()
            port = server.getsockname()[1]
            result = port_scanner.scan_ports(port, port)
        self.assertEqual(result["open_ports"][0]["port"], port)

    def test_rejects_bad_range(self):
        with self.assertRaises(ValueError):
            port_scanner.scan_ports(100, 1)


class WebAppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), main.Handler)
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        # Ignore any system proxy: we are only talking to this computer.
        cls.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def post(self, path, data, headers=None):
        request = urllib.request.Request(
            self.base + path, json.dumps(data).encode(),
            headers or {"Content-Type": "application/json"})
        return self.opener.open(request, timeout=5)

    def test_home_page(self):
        with self.opener.open(self.base, timeout=5) as response:
            self.assertIn(b"CyberShield", response.read())

    def test_api(self):
        with self.post("/api/password", {"password": "abc"}) as response:
            self.assertEqual(json.load(response)["label"], "Weak")

    def test_bad_requests_are_rejected(self):
        cases = [
            ("/api/password", {}, None, 400),
            ("/api/password", {"password": "x"}, {"Content-Type": "text/plain"}, 403),
            ("/api/password", {"password": "x"},
             {"Content-Type": "application/json", "Host": "evil.example"}, 403),
            ("/api/nothing", {}, None, 404),
        ]
        for path, data, headers, status in cases:
            with self.assertRaises(urllib.error.HTTPError) as caught:
                self.post(path, data, headers)
            self.assertEqual(caught.exception.code, status)
            caught.exception.close()


if __name__ == "__main__":
    unittest.main()
